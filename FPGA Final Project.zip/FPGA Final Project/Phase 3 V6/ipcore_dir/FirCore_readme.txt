The following files were generated for 'FirCore' in directory
E:\Documents\Darsi\FPGA\fir\v6\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * FirCore.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * FirCore.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * FirCore.ngc
   * FirCore.v
   * FirCore.veo
   * demo_tb/tb_FirCore.vhd

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * FirCore.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * FirCore.asy
   * FirCore.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * FirCore.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * FirCore_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * FirCore.gise
   * FirCore.xise

Deliver Readme:
   Readme file for the IP.

   * FirCore_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * FirCore_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

