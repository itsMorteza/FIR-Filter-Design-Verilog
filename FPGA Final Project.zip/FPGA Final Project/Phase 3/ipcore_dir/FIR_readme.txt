The following files were generated for 'FIR' in directory
E:\Documents\Darsi\FPGA\fir\fir_compiler\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * FIR.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * FIR.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * FIR.ngc
   * FIR.v
   * FIR.veo
   * FIRCOEFF_auto0_0.mif
   * FIRfilt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * FIR.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * FIR.asy
   * FIR.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * FIR.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * FIR_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * FIR.gise
   * FIR.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * FIR_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * FIR_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

