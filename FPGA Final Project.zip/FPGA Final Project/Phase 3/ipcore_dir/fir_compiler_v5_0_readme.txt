The following files were generated for 'fir_compiler_v5_0' in directory
E:\Documents\Darsi\FPGA\fir\fir_compiler\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * fir_compiler_v5_0.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * fir_compiler_v5_0.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * fir_compiler_v5_0.ngc
   * fir_compiler_v5_0.v
   * fir_compiler_v5_0.veo
   * fir_compiler_v5_0COEFF_auto0_0.mif
   * fir_compiler_v5_0COEFF_auto0_1.mif
   * fir_compiler_v5_0COEFF_auto0_2.mif
   * fir_compiler_v5_0COEFF_auto0_3.mif
   * fir_compiler_v5_0COEFF_auto0_4.mif
   * fir_compiler_v5_0COEFF_auto0_5.mif
   * fir_compiler_v5_0COEFF_auto0_6.mif
   * fir_compiler_v5_0COEFF_auto0_7.mif
   * fir_compiler_v5_0COEFF_auto0_8.mif
   * fir_compiler_v5_0COEFF_auto0_9.mif
   * fir_compiler_v5_0filt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * fir_compiler_v5_0.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * fir_compiler_v5_0.asy
   * fir_compiler_v5_0.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * fir_compiler_v5_0.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * fir_compiler_v5_0_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * fir_compiler_v5_0.gise
   * fir_compiler_v5_0.xise

Deliver Readme:
   Readme file for the IP.

   * fir_compiler_v5_0_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * fir_compiler_v5_0_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

