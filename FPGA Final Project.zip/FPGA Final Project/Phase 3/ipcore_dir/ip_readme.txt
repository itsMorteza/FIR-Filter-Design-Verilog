The following files were generated for 'ip' in directory
E:\xilinx\fir_compiler\ipcore_dir\

Opens the IP Customization GUI:
   Allows the user to customize or recustomize the IP instance.

   * ip.mif

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ip.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ip.ngc
   * ip.v
   * ip.veo
   * ipCOEFF_auto0_0.mif
   * ipCOEFF_auto0_1.mif
   * ipCOEFF_auto0_2.mif
   * ipCOEFF_auto0_3.mif
   * ipCOEFF_auto0_4.mif
   * ipCOEFF_auto0_5.mif
   * ipCOEFF_auto0_6.mif
   * ipCOEFF_auto0_7.mif
   * ipCOEFF_auto0_8.mif
   * ipCOEFF_auto0_9.mif
   * ipfilt_decode_rom.mif

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * ip.veo

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * ip.asy
   * ip.mif

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * ip.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * ip_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * ip.gise
   * ip.xise

Deliver Readme:
   Readme file for the IP.

   * ip_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ip_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

